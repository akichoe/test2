<?php

return [
	'merchantKey' => env('IPAY88_MERCHANT_KEY', "SAMPLE_KEY"),
	'merchantCode' => env('IPAY88_MERCHANT_CODE', "SAMPLE_CODE"),
];